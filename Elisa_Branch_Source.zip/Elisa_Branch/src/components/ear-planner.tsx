"use client";

import { useCallback, useEffect, useId, useRef, useState, type ReactNode } from "react";
import { Move, ArrowDownToLine, ArrowUpRight, Check, ChevronDown, PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen, Maximize2, Minimize2, Link2, Eye, EyeOff, FolderOpen, Hand, Info, Loader2, MapPin, Plus, RotateCcw, SlidersHorizontal, Trash2, Undo2, Upload, X, ZoomIn, ZoomOut } from "lucide-react";
import { EarScene } from "@/lib/ear-scene";
import { EMPTY_PLAN, FINISHES, TYPES, GAUGES, SKIN_TONES, DEFAULT_SKIN_TONE, canChain, cleanChains, finishColor, finishName, nextCustomNumber, makePiece, downloadFile, isPlan, readModel, storeModel, type Chain, type EarSide, type Finish, type JewelryType, type Piece, type Plan, type SavedLook, type V3 } from "@/lib/planner";
import { PIERCING_LOCATIONS, LOCATION_GROUPS, getLocation, type PiercingId } from "@/lib/piercing-locations";

function RoseMark({ small = false }: { small?: boolean }) {
  return <svg className="rose-mark" width={small ? 21 : 34} height={small ? 25 : 40} viewBox="0 0 64 76" aria-hidden="true" fill="#080808" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round"><path d="M32 9C23 2 16 8 16 16C6 17 4 29 12 36C7 47 19 54 31 48C43 55 57 47 52 36C62 28 57 16 47 15C45 5 37 3 32 9Z"/><path d="M32 15C40 11 48 19 45 27C54 34 45 45 37 43C31 51 19 43 21 35C10 31 17 18 25 20C25 15 29 14 32 15Z"/><path d="M25 20L37 19L43 28L37 38L26 37L21 29L25 20Z"/><path d="M29 23L37 24L38 31L31 35L26 30L29 23Z"/><path d="M30 28L35 27L35 31L31 32Z"/><path d="M16 16L25 20M12 36L21 35M31 48L37 43M52 36L45 27M47 15L37 19M32 9L32 15"/><path d="M32 49C30 58 35 66 32 74M32 64C21 66 17 58 16 55C24 55 29 58 32 64ZM33 59C41 60 47 53 48 50C39 50 35 53 33 59Z"/></svg>;
}

function JewelryGlyph({ type, finish = "silver", metalColor, small = false }: { type: JewelryType | "chain"; finish?: Finish; metalColor?: string; small?: boolean }) {
  const id = useId().replace(/:/g, "");
  const palette = finish === "custom" ? ["#ffffff",finishColor(finish,metalColor),finishColor(finish,metalColor),"#444444"] : finish === "gold" ? ["#fff4ca", "#b09248", "#ead494", "#8f702d"] : finish === "silver" ? ["#ffffff", "#969da4", "#e3e7eb", "#6f767f"] : ["#ffe9df", "#b57a68", "#e8bca8", "#915746"];
  return <svg className={small ? "jewel-glyph small" : "jewel-glyph"} viewBox="0 0 70 70" fill="none" aria-hidden="true"><defs><linearGradient id={`metal${id}`} x1="19" y1="13" x2="49" y2="56" gradientUnits="userSpaceOnUse">{palette.map((c, i) => <stop key={c} offset={`${i / 3 * 100}%`} stopColor={c}/>)}</linearGradient><radialGradient id={`ball${id}`} cx=".3" cy=".25" r=".75">{palette.slice(0, 3).map((c, i) => <stop key={c} offset={`${i / 2 * 100}%`} stopColor={c}/>)}</radialGradient><filter id={`shadow${id}`}><feGaussianBlur stdDeviation="2"/></filter></defs><ellipse cx="35" cy="56" rx="15" ry="3" fill="#7b625a" opacity=".13" filter={`url(#shadow${id})`}/>{type === "chain" ? <g stroke={`url(#metal${id})`} strokeWidth="3.5"><ellipse cx="25" cy="30" rx="10" ry="7" transform="rotate(-35 25 30)"/><ellipse cx="38" cy="37" rx="10" ry="7" transform="rotate(-35 38 37)"/><ellipse cx="49" cy="44" rx="10" ry="7" transform="rotate(-35 49 44)"/></g> : type === "plug" ? <><circle cx="35" cy="33" r="18" fill={`url(#metal${id})`}/><circle cx="35" cy="33" r="12" fill="#171717"/><circle cx="35" cy="33" r="15" stroke="#ececec" strokeWidth="1" opacity=".5"/></> : type === "hoop" ? <><circle cx="35" cy="33" r="18" stroke={`url(#metal${id})`} strokeWidth="5"/><path d="M35 12v6" stroke="#fff8db" strokeWidth="2.5" strokeLinecap="round"/></> : type === "barbell" ? <g transform="rotate(-30 35 35)"><path d="M35 20v30" stroke={`url(#metal${id})`} strokeWidth="4"/><circle cx="35" cy="19" r="7.5" fill={`url(#ball${id})`}/><circle cx="35" cy="49" r="7.5" fill={`url(#ball${id})`}/></g> : type === "gem" ? <><circle cx="35" cy="32" r="13.5" fill={`url(#metal${id})`}/><path d="m35 20 12 12-12 12-12-12z" fill="#e6e8e5"/><path d="m35 20 3 12-3 12-4-12z" fill="#fff"/><path d="m23 32 8 0 4 12z" fill="#c0cacd"/><path d="m47 32-9 0-3-12z" fill="#b4c1c8"/>{[0, 1, 2, 3].map(i => <circle key={i} cx={35 + Math.cos(i * Math.PI / 2) * 13} cy={32 + Math.sin(i * Math.PI / 2) * 13} r="2" fill={`url(#metal${id})`}/>)}</> : <><path d="m33 36 11 13" stroke={`url(#metal${id})`} strokeWidth="3"/><circle cx="31" cy="29" r="12" fill={`url(#ball${id})`}/><ellipse cx="27" cy="24" rx="3" ry="2" fill="#fffbe9" opacity=".65"/></>}</svg>;
}

function Modal({ title, children, onClose, wide = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose); closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const nodes = () => Array.from(ref.current?.querySelectorAll<HTMLElement>("button:not(:disabled), input:not(:disabled), a[href], select, textarea, [tabindex='0']") || []);
    const first = ref.current?.querySelector<HTMLElement>("[data-autofocus]") || nodes()[0]; first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab") { const all = nodes(); const first = all[0]; const last = all.at(-1); if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); } }
    };
    const old = document.body.style.overflow; document.body.style.overflow = "hidden";
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = old; previous?.focus(); };
  }, []);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div ref={ref} className={`modal ${wide ? "wide" : ""}`} role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-heading"><h2 id="modal-title">{title}</h2><button className="icon-btn" aria-label="Close dialog" onClick={onClose}><X size={19}/></button></div>{children}</div></div>;
}

function RangeField({ label, value, min, max, step = 0.1, unit = "mm", onChange }: { label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (n: number) => void }) {
  const id = useId();
  return <div className="range-field"><div className="range-label"><label htmlFor={id}>{label}</label><span><input aria-label={`${label} value`} type="number" min={min} max={max} step={step} value={Math.round(value * 100) / 100} onChange={e => { const n = e.target.valueAsNumber; if (Number.isFinite(n)) onChange(Math.min(max, Math.max(min, n))); }}/><span>{unit}</span></span></div><input id={id} aria-label={label} type="range" min={min} max={max} step={step} value={value} style={{ "--range-progress": `${(value - min) / (max - min) * 100}%` } as React.CSSProperties} onChange={e => onChange(Number(e.target.value))}/></div>;
}

function GaugeSelect({ value, plug = false, onChange }: { value: number; plug?: boolean; onChange: (value: number) => void }) {
  const id = useId();
  const options = plug ? [...GAUGES.filter(g => g.mm >= 1.6), ...[12,14,16,18,20,22,24].map(mm => ({label: `${mm} mm`,mm}))] : GAUGES.filter(g => g.mm <= 5);
  const known = options.some(g => Math.abs(g.mm - value) < .001);
  return <div className="location-picker gauge-picker"><label className="micro-label" htmlFor={id}>{plug ? "PLUG GAUGE" : "GAUGE"}</label><select id={id} aria-label={plug ? "Plug gauge" : "Gauge"} value={known ? value : "custom"} onChange={e => onChange(Number(e.target.value))}>{!known && <option value="custom" disabled>Custom · {value} mm</option>}{options.map(g => <option key={g.mm} value={g.mm}>{g.label}{g.label.endsWith("mm") ? "" : ` · ${g.mm} mm`}</option>)}</select></div>;
}

const CURRENT_KEY = "ear-studio-current-v1";
const LOOKS_KEY = "ear-studio-looks-v1";

type LocationChoice = PiercingId | `custom:${string}` | "add-custom";
function pieceLocation(piece: Piece): LocationChoice | undefined { return piece.custom ? `custom:${piece.id}` : piece.locationId; }
function rgbChannels(color: string) { return [1,3,5].map(i => parseInt(color.slice(i,i+2),16)); }
function rgbHex(channels: number[]) { return "#" + channels.map(v => Math.round(Math.min(255,Math.max(0,v))).toString(16).padStart(2,"0")).join(""); }
function FinishPicker({finish,metalColor,onChange,label}:{finish:Finish;metalColor?:string;onChange:(finish:Finish,color?:string)=>void;label:string}) {
  const color = metalColor || finishColor(finish), channels = rgbChannels(color);
  return <div className="metal-picker"><div className="metal-options" role="group" aria-label={label}>
    {FINISHES.map(f => <button key={f.id} type="button" aria-label={`${label}: ${f.name}`} aria-pressed={finish === f.id} className={finish === f.id ? "active" : ""} onClick={() => onChange(f.id,f.id === "custom" ? color : undefined)}><i style={{background:`linear-gradient(135deg,#fff9,${f.id === "custom" ? color : f.color} 50%,#0004)`}}/>{f.name}</button>)}
  </div>{finish === "rose" && <span className="metal-current">Current finish: Rose gold</span>}{finish === "custom" && <div className="metal-rgb"><input type="color" aria-label={`${label} custom color`} value={color} onInput={e => onChange("custom",e.currentTarget.value)} onChange={e => onChange("custom",e.target.value)}/>{["R","G","B"].map((channel,index) => <label key={channel}>{channel}<input type="number" min={0} max={255} step={1} aria-label={`${label} ${channel}`} value={channels[index]} onChange={e => { const n=e.target.valueAsNumber;if(Number.isFinite(n)){const next=[...channels];next[index]=n;onChange("custom",rgbHex(next));} }}/></label>)}</div>}</div>;
}
function LocationSelect({ value, onChange, label, occupied = [], customPieces = [], allowAddCustom = true, disabled = false, lobeOnly = false }: { value: LocationChoice; onChange: (id: LocationChoice) => void; label: string; occupied?: PiercingId[]; customPieces?:Piece[]; allowAddCustom?:boolean; disabled?: boolean; lobeOnly?: boolean }) {
  const id = useId(), added = occupied.includes(value as PiercingId) || value.startsWith("custom:");
  const addedStyle = {fontWeight:700,backgroundColor:"#301010",color:"#ffe6df"};
  return <div className={`location-picker ${added ? "has-piece" : ""}`}><label className="micro-label" htmlFor={id}>{label}</label><select id={id} aria-label={label} disabled={disabled} value={value} onChange={e => onChange(e.target.value as LocationChoice)}>{LOCATION_GROUPS.filter(group => !lobeOnly || group === "Lobe").map(group => <optgroup key={group} label={group}>{PIERCING_LOCATIONS.filter(location => location.group === group).map(location => <option style={occupied.includes(location.id) ? addedStyle : undefined} value={location.id} key={location.id}>{occupied.includes(location.id) ? "● " : ""}{location.name}{occupied.includes(location.id) ? " · added" : ""}</option>)}</optgroup>)}{(allowAddCustom || customPieces.length>0) && <optgroup label="Custom piercings">{customPieces.map(piece => <option key={piece.id} value={`custom:${piece.id}`} style={addedStyle}>● {piece.name}</option>)}{allowAddCustom && <option value="add-custom">+ Add New Custom</option>}</optgroup>}</select></div>;
}

export default function EarPlanner() {
  const [libraryOpen, setLibraryOpen] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(true);
  const focused = !libraryOpen && !settingsOpen;
  const [plan, setPlan] = useState<Plan>({ ...EMPTY_PLAN });
  const [side, setSide] = useState<EarSide>("left");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeType, setActiveType] = useState<JewelryType>("stud");
  const [locationId, setLocationId] = useState<LocationChoice>("lobe-1");
  const [chainMode, setChainMode] = useState(false);
  const [chainFrom, setChainFrom] = useState("");
  const [chainTo, setChainTo] = useState("");
  const [chainDrop, setChainDrop] = useState(8);
  const [finish, setFinish] = useState<Finish>("silver");
  const [metalColor,setMetalColor] = useState("#aeb6bd");
  const [freeMove,setFreeMove] = useState(false);
  const [engine, setEngine] = useState<EarScene | null>(null);
  const [booted, setBooted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sceneError, setSceneError] = useState("");
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [looks, setLooks] = useState<SavedLook[]>([]);
  const [notice, setNotice] = useState("");
  const [modal, setModal] = useState<"save" | "saved" | "model" | "appearance" | null>(null);
  const [lookName, setLookName] = useState("");
  const [clay, setClay] = useState(true);
  const [view, setView] = useState("front");
  const [modelHeight, setModelHeight] = useState(65);
  const [importing, setImporting] = useState(false);
  const [historySize, setHistorySize] = useState(0);
  const [localSaved, setLocalSaved] = useState(true);
  const canvasRef = useRef<HTMLDivElement>(null);
  const modelInput = useRef<HTMLInputElement>(null);
  const planInput = useRef<HTMLInputElement>(null);
  const history = useRef<Plan[]>([]);
  const planRef = useRef(plan); planRef.current = plan;
  const seed = useRef(true);
  const selectionCallback = useRef<(id: string | null) => void>(() => {});
  const selected = plan[side].find(p => p.id === selectedId) || null;
  const pieces = plan[side];
  const chains = (plan.chains || []).filter(c => c.side === side);
  const selectedChain = chains.find(c => c.id === selectedId);
  const chainCandidates = pieces.filter(p => p.visible && canChain(p));
  const fromId = chainCandidates.some(p => p.id === chainFrom) ? chainFrom : chainCandidates[0]?.id || "";
  const toId = chainCandidates.some(p => p.id === chainTo && p.id !== fromId) ? chainTo : chainCandidates.find(p => p.id !== fromId)?.id || "";

  const occupyingPiece = pieces.find(piece => pieceLocation(piece) === locationId);
  const activeLocation = getLocation(locationId) || {name:occupyingPiece?.name || "Custom piercing",group:"Custom"};
  selectionCallback.current = id => {
    setSelectedId(id); setChainMode(!!chains.find(c => c.id === id));
    const piece = pieces.find(item => item.id === id);
    if (piece) { setLocationId(pieceLocation(piece) || "lobe-1"); setActiveType(piece.type); setFinish(piece.finish); setMetalColor(piece.metalColor || finishColor(piece.finish)); }
  };

  const commit = useCallback((update: Plan | ((p: Plan) => Plan)) => {
    const previous = planRef.current;
    const next = cleanChains(typeof update === "function" ? update(previous) : update);
    history.current = [...history.current.slice(-39), previous]; planRef.current = next;
    setPlan(next); setHistorySize(history.current.length);
  }, []);
  const undo = useCallback(() => {
    const previous = history.current.pop();
    if (previous) { planRef.current = previous; setPlan(previous); setHistorySize(history.current.length); setSelectedId(null); }
  }, []);
  const updatePiece = (updates: Partial<Piece>, id = selectedId) => {
    if (!id) return;
    commit(p => ({ ...p, [side]: p[side].map(item => item.id === id ? { ...item, ...updates } : item) }));
  };

  const dragStart = useRef<{plan:Plan;side:EarSide} | null>(null);
  const moveCallback = useRef<(id:string,offset:V3,phase:"start"|"move"|"end"|"cancel")=>void>(()=>{});
  moveCallback.current = (id,offset,phase) => {
    if(phase === "start") { dragStart.current={plan:planRef.current,side}; return; }
    const start=dragStart.current; if(!start) return;
    if(phase === "cancel") { planRef.current=start.plan;setPlan(start.plan);dragStart.current=null;return; }
    if(phase === "move") {
      const original=start.plan[start.side].find(p=>p.id===id);if(!original) return;
      const base=original.adjustment?.position || [0,0,0];
      if(offset.every((v,i)=>Math.abs(v-base[i])<1e-9) && planRef.current===start.plan) return;
      const current=planRef.current;
      const next={...current,[start.side]:current[start.side].map(p=>p.id===id ? {...p,adjustment:{position:offset,rotation:p.adjustment?.rotation || [0,0,0] as V3}} : p)};
      planRef.current=next;setPlan(next);return;
    }
    if(planRef.current!==start.plan) {history.current=[...history.current.slice(-39),start.plan];setHistorySize(history.current.length);}
    dragStart.current=null;
  };
  useEffect(() => {
    try {
      const current = JSON.parse(localStorage.getItem(CURRENT_KEY) || "null");
      if (current && isPlan(current.plan)) { setPlan(current.plan); setSide(current.side === "right" ? "right" : "left"); seed.current = false; }
      const saved = JSON.parse(localStorage.getItem(LOOKS_KEY) || "[]");
      if (Array.isArray(saved)) setLooks(saved.filter(l => l && typeof l.id === "string" && typeof l.name === "string" && typeof l.thumbnail === "string" && typeof l.savedAt === "string" && isPlan(l.plan)).slice(0, 24));
    } catch { setNotice("The previous session could not be restored."); }
    setBooted(true);
  }, []);
  useEffect(() => {
    if (!canvasRef.current) return;
    let scene: EarScene;
    try {
      scene = new EarScene(canvasRef.current, { onSelect: id => selectionCallback.current(id), onMove:(id,offset,phase)=>moveCallback.current(id,offset,phase) }); setEngine(scene);
    } catch { setSceneError("3D rendering could not start. Try a browser with WebGL enabled."); setLoading(false); return; }
    return () => scene.dispose();
  }, []);
  useEffect(() => {
    if (!booted || !engine) return;
    let cancelled = false; setLoading(true); setSceneError("");
    (async () => {
      const buffer = plan.modelId === "demo-ear-v1" ? undefined : await readModel(plan.modelId);
      const loaded = await engine.load(buffer);
      if (cancelled || !loaded) return;
      engine.setHeight(plan.height); engine.setSide(side);
      if (seed.current) {
        seed.current = false;
        setPlan(p => ({ ...p, left: [] })); setSelectedId(null);
      } else setPlan(p => engine.restorePlan(p));
      setLoading(false);
    })().catch(error => { if (!cancelled) { setSceneError(error instanceof Error ? error.message : "The model could not be loaded."); setLoading(false); } });
    return () => { cancelled = true; };
    // Model geometry is reloaded only when its identity changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booted, engine, plan.modelId, loadAttempt]);
  useEffect(() => { if (!engine || loading) return; engine.setHeight(plan.height); engine.setSide(side); engine.setPieces(pieces, selectedId, chains); }, [engine, loading, plan.height, pieces, plan.chains, selectedId, side]);
  useEffect(() => { if (!engine || loading) return; engine.setPresetHint(chainMode || occupyingPiece || !getLocation(locationId) ? null : locationId as PiercingId); }, [engine, loading, locationId, occupyingPiece, side, plan.height, chainMode]);
  useEffect(() => { engine?.setFreeMove(freeMove); }, [engine,freeMove]);
  useEffect(() => { if (!selected) setFreeMove(false); }, [selected?.id]);
  useEffect(() => {
    if (!pieces.length) setFreeMove(false);
    if (locationId.startsWith("custom:") && !pieces.some(piece => pieceLocation(piece) === locationId)) { setLocationId("lobe-1");setSelectedId(null); }
  }, [pieces,locationId]);
  useEffect(() => { engine?.setClay(clay); }, [engine, clay]);
  useEffect(() => { engine?.setSkinTone(plan.skinTone || DEFAULT_SKIN_TONE); }, [engine, plan.skinTone]);
  useEffect(() => {
    if (!booted || loading || sceneError) return;
    try { localStorage.setItem(CURRENT_KEY, JSON.stringify({ plan, side })); setLocalSaved(true); } catch { setLocalSaved(false); }
  }, [plan, side, booted, loading, sceneError]);
  useEffect(() => { if (!notice) return; const timer = setTimeout(() => setNotice(""), 4500); return () => clearTimeout(timer); }, [notice]);
  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.matches("input, textarea, select") || modal) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") { e.preventDefault(); undo(); }
      if (e.key === "Escape") setSelectedId(null);
    }; window.addEventListener("keydown", listener); return () => window.removeEventListener("keydown", listener);
  }, [undo, modal]);

  function applySkinTone(color: string) {
    setClay(true);
    if ((planRef.current.skinTone || DEFAULT_SKIN_TONE) !== color) commit(p => ({...p, skinTone:color}));
  }
  function chooseType(type: JewelryType) { setChainMode(false); setActiveType(type); }
  function chooseLocation(id: LocationChoice) {
    if(id === "add-custom") {addCustom();return;}
    const spec=getLocation(id);setChainMode(false);setLocationId(id);
    const existing=pieces.find(p=>pieceLocation(p)===id);
    setSelectedId(existing?.id || null);setActiveType(existing?.type || spec?.type || "stud");
    if(existing) {setFinish(existing.finish);setMetalColor(existing.metalColor || finishColor(existing.finish));}
    if(view === "back")setCamera("front");
  }
  function addCustom() {
    if(!engine || loading) return;
    if(pieces.length>=100) {setNotice("This ear already has 100 pieces.");return;}
    const piece=engine.customPiece(nextCustomNumber(pieces),side,activeType,finish,metalColor);
    if(!piece) {setNotice("The model has no surface at the starting location.");return;}
    commit(p=>({...p,[side]:[...p[side],piece]}));setSelectedId(piece.id);setLocationId(`custom:${piece.id}`);setChainMode(false);setFreeMove(true);
    setNotice(`${piece.name} added. Drag it to position it.`);
  }
  function addAtPreset() {
    if(!engine || loading)return;
    const presetId=getLocation(locationId)?.id;
    if(activeType === "plug" && activeLocation.group !== "Lobe" && !occupyingPiece?.custom)return;
    const piece=presetId ? engine.presetPiece(presetId,side,activeType,finish) : occupyingPiece ? makePiece(activeType,occupyingPiece.position,occupyingPiece.normal,finish,metalColor) : null;
    if(!piece){setNotice("This location is outside the model surface.");return;}
    if(occupyingPiece) {
      const updates=occupyingPiece.type === activeType ? {...occupyingPiece,finish,metalColor:finish === "custom" ? metalColor : undefined,visible:true} : {...piece,id:occupyingPiece.id,name:occupyingPiece.name,custom:occupyingPiece.custom,customNumber:occupyingPiece.customNumber,position:occupyingPiece.position,normal:occupyingPiece.normal,rotation:occupyingPiece.rotation,tilt:occupyingPiece.tilt,lift:occupyingPiece.lift,adjustment:occupyingPiece.adjustment,finish,metalColor:finish === "custom" ? metalColor : undefined};
      commit(p=>({...p,[side]:p[side].map(item=>item.id===occupyingPiece.id ? updates : item)}));setSelectedId(occupyingPiece.id);
    } else {
      if(pieces.length>=100){setNotice("This ear already has 100 pieces.");return;}
      piece.metalColor=finish === "custom" ? metalColor : undefined;
      commit(p=>({...p,[side]:[...p[side],piece]}));setSelectedId(piece.id);
    }
    setNotice(`${activeLocation.name} ${occupyingPiece ? "updated" : "added"}.`);
  }
  function relocateSelected(id: LocationChoice) {
    if(!engine || !selected)return;
    if(id.startsWith("custom:")){if(id!==pieceLocation(selected))setNotice("That custom piece already exists. Select it in the piercing menu.");return;}
    const spec=getLocation(id);if(!spec)return;
    if(pieces.some(p=>p.locationId===id && p.id!==selected.id)){setNotice("There is already a piece at that location.");return;}
    const preset=engine.presetPiece(spec.id,side,selected.type,selected.finish);
    if(!preset){setNotice("That location is outside the model surface.");return;}
    updatePiece({position:preset.position,normal:preset.normal,rotation:preset.rotation,tilt:preset.tilt,lift:preset.lift,adjustment:undefined,custom:undefined,customNumber:undefined,locationId:spec.id,name:selected.name===getLocation(selected.locationId)?.name ? spec.name : selected.name});setLocationId(spec.id);
  }
  function changeSide(next: EarSide) { engine?.setFreeMove(false); setFreeMove(false); setSide(next); setSelectedId(null); setChainMode(false); setView("front"); engine?.setSide(next); engine?.resetView(); }
  function setCamera(next: "front" | "angle" | "back") { setView(next); engine?.resetView(next); }
  function removePiece(id: string) { commit(p => ({ ...p, [side]: p[side].filter(item => item.id !== id) })); if (id === selectedId) setSelectedId(null); }
  function addChain() {
    if (!fromId || !toId || fromId === toId) return;
    const existing = chains.find(c => [c.fromId,c.toId].sort().join("|") === [fromId,toId].sort().join("|"));
    if (existing) { setSelectedId(existing.id); setNotice("That connection already exists. Adjust it in Jewelry settings."); return; }
    if ((plan.chains || []).length >= 40) { setNotice("This plan already has 40 chains."); return; }
    const chain: Chain = {id:crypto.randomUUID(),side,fromId,toId,drop:chainDrop,thickness:.25,finish,metalColor:finish === "custom" ? metalColor : undefined,visible:true};
    commit(p => ({...p,chains:[...(p.chains || []),chain]})); setSelectedId(chain.id);
  }
  function updateChain(updates: Partial<Chain>, id = selectedId) {
    commit(p => ({...p,chains:(p.chains || []).map(c => c.id === id ? {...c,...updates} : c)}));
  }
  function deleteChain(id: string) {
    commit(p => ({...p,chains:(p.chains || []).filter(c => c.id !== id)})); setSelectedId(null);
  }
  function chainName(c: Chain) { return `${pieces.find(p => p.id === c.fromId)?.name || "Piece"} ↔ ${pieces.find(p => p.id === c.toId)?.name || "Piece"}`; }
  function saveLook() {
    if (!engine || !lookName.trim()) return;
    const saved: SavedLook = { id: crypto.randomUUID(), name: lookName.trim().slice(0, 60), savedAt: new Date().toISOString(), side, plan: structuredClone(plan), thumbnail: engine.snapshot(true) };
    const next = [saved, ...looks].slice(0, 24);
    try { localStorage.setItem(LOOKS_KEY, JSON.stringify(next)); setLooks(next); setModal(null); setNotice(`“${saved.name}” saved on this device.`); }
    catch { setNotice("Your browser storage is full. Export your plan to keep a copy."); }
  }
  async function openLook(look: SavedLook) {
    if (look.plan.modelId !== "demo-ear-v1") { try { await readModel(look.plan.modelId); } catch (e) { setNotice((e as Error).message); return; } }
    const restored = structuredClone(look.plan);
    seed.current = false; commit(engine && restored.modelId === plan.modelId ? engine.restorePlan(restored) : restored); setSide(look.side); setSelectedId(null); setModal(null); setView("front"); engine?.resetView(); setNotice(`Opened “${look.name}” with its saved placement.`);
  }
  function deleteLook(id: string) {
    const next = looks.filter(l => l.id !== id);
    try { localStorage.setItem(LOOKS_KEY, JSON.stringify(next)); setLooks(next); } catch { setNotice("The saved look could not be removed."); }
  }
  function exportPlan() {
    downloadFile(JSON.stringify(plan, null, 2), "elisa-planner-plan.json"); setNotice("Plan exported. Keep the model file too if you imported your own.");
  }
  async function importPlan(file?: File) {
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error("This plan file is too large.");
      const imported = JSON.parse(await file.text());
      if (!isPlan(imported)) throw new Error("This is not a valid Elisa Planner plan.");
      if (imported.modelId !== "demo-ear-v1") await readModel(imported.modelId);
      seed.current = false; commit(engine && imported.modelId === plan.modelId ? engine.restorePlan(imported) : imported); setSelectedId(null); setModal(null); setNotice("Your plan is open with its saved placement.");
    } catch (error) { setNotice((error as Error).message || "The plan could not be opened."); }
    if (planInput.current) planInput.current.value = "";
  }
  async function importModel(file?: File) {
    if (!file || !engine) return;
    setImporting(true);
    try {
      if (file.size > 50 * 1024 * 1024) throw new Error("Choose a GLB smaller than 50 MB.");
      const buffer = await file.arrayBuffer();
      if (buffer.byteLength < 20 || new DataView(buffer).getUint32(0, true) !== 0x46546c67) throw new Error("Please choose a valid .glb model file.");
      await engine.load(buffer);
      const id = crypto.randomUUID(); await storeModel(id, buffer);
      seed.current = false; commit({ ...EMPTY_PLAN, modelId: id, modelName: file.name.replace(/\.glb$/i, ""), height: modelHeight, skinTone:plan.skinTone });
      setSelectedId(null); setModal(null); setNotice("Your model is ready. Choose a named piercing location to add jewelry.");
    } catch (error) {
      setNotice((error as Error).message || "This model could not be imported.");
      try { await engine.load(plan.modelId === "demo-ear-v1" ? undefined : await readModel(plan.modelId)); engine.setHeight(plan.height); engine.setSide(side); engine.setPieces(pieces, selectedId, chains); } catch { setSceneError("The model could not be restored. Reload the page to try again."); }
    } finally { setImporting(false); if (modelInput.current) modelInput.current.value = ""; }
  }
  function calibrateHeight() {
    const ratio = modelHeight / plan.height;
    const rescale = (ps: Piece[]) => ps.map(p => ({ ...p, position: p.position.map(v => v * ratio) as V3 }));
    commit(p => ({ ...p, height: modelHeight, left: rescale(p.left), right: rescale(p.right) })); setModal(null); setNotice("Reference height updated. Jewelry dimensions stay the same.");
  }
  function imageExport() {
    if (!engine || loading) return;
    const a = document.createElement("a"); a.href = engine.snapshot(); a.download = `elisa-planner-${side}-ear.png`; a.click(); setNotice("Your current view has been exported.");
  }

  return <div className="studio-app">
    <header className="site-header">
      <a className="brand" href={import.meta.env.BASE_URL} aria-label="Elisa Planner home"><RoseMark/><span>Elisa Planner</span><svg className="brand-vine" viewBox="0 0 270 18" preserveAspectRatio="none" fill="none" stroke="currentColor" strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path vectorEffect="non-scaling-stroke" d="M0 0C1 13 16 16 39 13C78 7 128 17 174 12C216 7 244 14 267 4"/><path className="vine-leaf" vectorEffect="non-scaling-stroke" d="M38 13C30 12 27 7 26 4C34 4 39 8 38 13ZM93 11C102 10 106 5 107 2C99 2 94 6 93 11ZM183 11C177 11 173 6 173 3C181 3 185 7 183 11ZM242 11C250 10 254 5 254 2C247 2 243 6 242 11Z"/><path vectorEffect="non-scaling-stroke" d="M66 11L71 15L70 11M141 13L146 17L145 13M220 10L225 14L224 10"/></svg></a>
      <nav className="main-nav" aria-label="Workspace"><button className="nav-active" onClick={() => setModal(null)}>Planner</button><button onClick={() => setModal("saved")}>Saved looks <span className="nav-count">{looks.length}</span></button></nav>
      <div className="header-actions"><button className="btn btn-quiet focus-toggle" aria-label={focused ? "Show sidebars" : "Focus on ear"} aria-pressed={focused} onClick={() => { setLibraryOpen(focused); setSettingsOpen(focused); }}>{focused ? <Minimize2 size={16}/> : <Maximize2 size={16}/>}<span className="focus-label">{focused ? "Show panels" : "Focus view"}</span></button><button className="mobile-saved icon-btn" aria-label="Open saved looks" onClick={() => setModal("saved")}><FolderOpen size={17}/></button><button aria-label="Import model" className="btn btn-quiet import-btn" onClick={() => { setModelHeight(plan.height); setModal("model"); }}><Upload size={15}/><span>Import model</span></button><button className="btn btn-dark" aria-label="Save look" disabled={loading || !!sceneError} onClick={() => { setLookName(`Arrangement ${looks.length + 1}`); setModal("save"); }}><Plus size={16}/><span className="save-label">Save look</span></button></div>
    </header>

    <main className="main-shell" aria-label="Elisa Planner">

      <div className={`workspace ${!libraryOpen ? "library-hidden" : ""} ${!settingsOpen ? "settings-hidden" : ""} ${focused ? "focus-view" : ""}`}>
        <aside id="jewelry-library" className="library-panel" aria-label="Jewelry library" hidden={!libraryOpen}>
          <div className="panel-heading"><span className="section-number">1.</span><h2>Choose a piercing</h2><button className="collapse-panel-button icon-btn" aria-label="Hide jewelry sidebar" aria-expanded={libraryOpen} aria-controls="jewelry-library" onClick={() => setLibraryOpen(false)}><PanelLeftClose size={17}/></button></div>
          
          <LocationSelect value={locationId} onChange={chooseLocation} label="PIERCING LOCATION" customPieces={pieces.filter(p=>p.custom)} occupied={pieces.map(piece => piece.locationId).filter((id): id is PiercingId => !!id)} disabled={loading || !!sceneError}/>
          
          <div className="panel-heading style-heading"><span className="section-number">2.</span><h2>Choose a jewelry style</h2></div>
          <div className="jewelry-library">{TYPES.map(type => <button key={type.id} className={`jewelry-card ${!chainMode && activeType === type.id ? "active" : ""}`} disabled={loading || !!sceneError || (type.id === "plug" && activeLocation.group !== "Lobe" && !occupyingPiece?.custom)} onClick={() => chooseType(type.id)} aria-label={`Choose ${type.name.toLowerCase()}`}><span className="jewelry-art"><JewelryGlyph type={type.id} finish={finish} metalColor={metalColor}/><span className="card-plus">{!chainMode && activeType === type.id ? <Check size={12}/> : <Plus size={12}/>}</span></span><span className="jewelry-card-name">{type.name}</span></button>)}<button className={`jewelry-card ${chainMode ? "active" : ""}`} aria-label="Choose chain" disabled={loading || !!sceneError} onClick={() => { setChainMode(true); setSelectedId(null); }}><span className="jewelry-art"><JewelryGlyph type="chain" finish={finish} metalColor={metalColor}/><span className="card-plus">{chainMode ? <Check size={12}/> : <Plus size={12}/>}</span></span><span className="jewelry-card-name">Chain</span></button></div>
          {chainMode && <div className="chain-builder"><div className="location-picker"><label htmlFor="chain-from" className="micro-label">CONNECT FROM</label><select id="chain-from" aria-label="Chain from" value={fromId} onChange={e => setChainFrom(e.target.value)}>{!chainCandidates.length && <option value="">Add a stud, gem, hoop, or barbell</option>}{chainCandidates.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div><div className="location-picker"><label htmlFor="chain-to" className="micro-label">CONNECT TO</label><select id="chain-to" aria-label="Chain to" value={toId} onChange={e => setChainTo(e.target.value)}>{!toId && <option value="">Add another piece</option>}{chainCandidates.filter(p => p.id !== fromId).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div><RangeField label="New chain drop" value={chainDrop} min={0} max={35} step={.5} onChange={setChainDrop}/>{chainCandidates.length < 2 && <p className="field-note">Add two visible pieces on this ear to connect a chain.</p>}</div>}
          <div className="library-finish"><span className="micro-label">NEW PIECE FINISH</span><FinishPicker label="New jewelry finish" finish={finish} metalColor={metalColor} onChange={(value,color)=>{setFinish(value);if(color)setMetalColor(color);}}/></div>
          <button className="btn btn-dark add-preset-btn" aria-label={chainMode ? "Connect pieces" : `${occupyingPiece ? "Update" : "Add"} ${activeLocation.name}`} onClick={chainMode ? addChain : addAtPreset} disabled={loading || !!sceneError || (chainMode && (!fromId || !toId)) || (!chainMode && activeType === "plug" && activeLocation.group !== "Lobe" && !occupyingPiece?.custom)}>{chainMode ? <Link2 size={14}/> : <MapPin size={14}/>}<span>{chainMode ? "Connect pieces" : `${occupyingPiece ? "Update" : "Add"} ${activeLocation.name.toLowerCase()}`}</span></button>
          <p className="preset-disclaimer">{chainMode ? "Visual drape between pieces; attachment hardware is not modeled." : occupyingPiece?.custom ? "Custom placement." : activeType === "plug" ? "Plugs are available at lobe locations." : "One piece per location."}</p>
          
        </aside>

        <section className="stage" aria-label="3D planning workspace">
          {!libraryOpen && <button className="panel-restore restore-library" aria-label="Show jewelry sidebar" aria-expanded={false} aria-controls="jewelry-library" onClick={() => setLibraryOpen(true)}><PanelLeftOpen size={18}/><span>Jewelry</span></button>}
          {!settingsOpen && <button className="panel-restore restore-settings" aria-label="Show settings sidebar" aria-expanded={false} aria-controls="jewelry-settings" onClick={() => setSettingsOpen(true)}><PanelRightOpen size={18}/><span>Settings</span></button>}
          <div className="stage-top"><div className="ear-switch" role="group" aria-label="Choose ear"><button aria-pressed={side === "left"} className={side === "left" ? "active" : ""} onClick={() => changeSide("left")}>Left ear</button><button aria-pressed={side === "right"} className={side === "right" ? "active" : ""} onClick={() => changeSide("right")}>Right ear</button></div><button className="stage-model-label" onClick={() => { setModelHeight(plan.height); setModal("model"); }}><span className="status-dot"/>{plan.modelId === "demo-ear-v1" ? "TEST MODEL" : "YOUR MODEL"}<ChevronDown size={12}/></button></div>
          <div className="canvas-wrap" ref={canvasRef}/>
          {(loading || sceneError) && <div className="stage-loading" role="status">{sceneError ? <><Info size={25}/><p>{sceneError}</p><button className="btn btn-dark" onClick={() => { if (!engine) { window.location.reload(); return; } seed.current = false; commit(p => ({ ...EMPTY_PLAN, skinTone:p.skinTone })); setLoadAttempt(n => n + 1); }}>Use test model</button></> : <><Loader2 className="spin" size={27}/><p>Loading ear model…</p></>}</div>}
          {!loading && !sceneError && <><div className="stage-side-note"><span>REFERENCE HEIGHT</span><button onClick={() => { setModelHeight(plan.height); setModal("model"); }}>{plan.height}<small> mm</small><SlidersHorizontal size={11}/></button></div><div className="zoom-controls"><button className="icon-btn" aria-label="Zoom in" title="Zoom in" onClick={() => engine?.zoom(1)}><ZoomIn size={17}/></button><span/><button className="icon-btn" aria-label="Zoom out" title="Zoom out" onClick={() => engine?.zoom(-1)}><ZoomOut size={17}/></button></div><div className="active-preset-badge"><MapPin size={12}/><span>{activeLocation.name}</span><small>{occupyingPiece?.custom ? "CUSTOM" : "PRESET"}</small></div><div className="stage-instruction"><Hand size={14}/><span>{freeMove ? "Drag jewelry to move · Drag ear to rotate" : "Drag to rotate · Scroll or pinch to zoom"}</span></div></>}
          <div className="stage-bottom"><div className="camera-views" role="group" aria-label="Camera view">{(["front", "angle", "back"] as const).map(v => <button key={v} className={view === v ? "active" : ""} onClick={() => setCamera(v)}>{v === "angle" ? "¾ view" : `${v[0].toUpperCase()}${v.slice(1)}`}</button>)}</div><div className="stage-tools"><button className="icon-btn" title="Undo last change" aria-label="Undo last change" disabled={!historySize} onClick={undo}><Undo2 size={16}/></button><button className="icon-btn" title="Reset camera" aria-label="Reset camera" onClick={() => setCamera("front")}><RotateCcw size={16}/></button><button className="icon-btn" title="Export image" aria-label="Export image" disabled={loading || !!sceneError} onClick={imageExport}><ArrowDownToLine size={17}/></button></div></div>
        </section>

        <aside id="jewelry-settings" className="inspector-panel" aria-label="Your arrangement and jewelry controls" hidden={!settingsOpen}>
          <div className="panel-heading"><span className="section-number">3.</span><h2>Jewelry settings</h2><span className="piece-count">{pieces.length}</span><button className="collapse-panel-button icon-btn" aria-label="Hide settings sidebar" aria-expanded={settingsOpen} aria-controls="jewelry-settings" onClick={() => setSettingsOpen(false)}><PanelRightClose size={17}/></button></div>
          <div className="arrangement-label"><span className="micro-label">YOUR {side.toUpperCase()} EAR</span><button onClick={() => { if (pieces.length) { commit(p => ({ ...p, [side]: [] })); setSelectedId(null); } }} disabled={!pieces.length}>Clear</button></div>
          <div className="piece-list">{pieces.length ? pieces.map((p, i) => <div key={p.id} className={`piece-row ${selectedId === p.id ? "selected" : ""} ${!p.visible ? "hidden-piece" : ""}`}><button className="piece-select" onClick={() => selectionCallback.current(p.id)} aria-label={`Edit ${p.name}`}><span className="piece-index">{String(i + 1).padStart(2, "0")}</span><JewelryGlyph type={p.type} finish={p.finish} metalColor={p.metalColor} small/><span><strong>{p.name}</strong><small>{p.type === "hoop" ? `${p.size} mm hoop` : `${p.size} mm · ${finishName(p.finish)}`}</small></span></button><button className="visibility-btn" aria-label={`${p.visible ? "Hide" : "Show"} ${p.name}`} title={p.visible ? "Hide piece" : "Show piece"} onClick={() => updatePiece({ visible: !p.visible }, p.id)}>{p.visible ? <Eye size={14}/> : <EyeOff size={14}/>}</button></div>) : <div className="empty-stack"><RoseMark small/><p>No jewelry added.</p><span>Choose a location and add its jewelry.</span></div>}</div>

          {chains.length > 0 && <div className="chain-list">{chains.map(c => <div key={c.id} className={`piece-row ${selectedId === c.id ? "selected" : ""} ${!c.visible ? "hidden-piece" : ""}`}><button className="piece-select" aria-label={`Edit chain ${chainName(c)}`} onClick={() => { setSelectedId(c.id); setChainMode(true); }}><JewelryGlyph type="chain" finish={c.finish} metalColor={c.metalColor} small/><span><strong>{chainName(c)}</strong><small>{c.drop} mm drop</small></span></button><button className="visibility-btn" aria-label={`${c.visible ? "Hide" : "Show"} chain ${chainName(c)}`} onClick={() => updateChain({visible:!c.visible},c.id)}>{c.visible ? <Eye size={14}/> : <EyeOff size={14}/>}</button></div>)}</div>}

          {selected ? <div className="piece-editor" key={selected.id}><div className="editor-heading"><span className="micro-label">SELECTED JEWELRY</span><button className="delete-piece-button" aria-label="Delete selected piece" title="Delete piece" onClick={() => removePiece(selected.id)}><Trash2 size={14}/><span>Delete</span></button></div><label className="piece-name-label"><span className="sr-only">Piece name</span><input aria-label="Piece name" value={selected.name} maxLength={60} onChange={e => updatePiece({ name: e.target.value })}/></label><div className="selected-piece-actions"><button className={`free-move-toggle ${freeMove ? "active" : ""}`} aria-label="Free move" aria-pressed={freeMove} disabled={loading || !!sceneError} onClick={()=>setFreeMove(value=>!value)}><Move size={14}/><span>Free move</span></button></div><FinishPicker label="Selected jewelry finish" finish={selected.finish} metalColor={selected.metalColor} onChange={(value,color)=>updatePiece({finish:value,metalColor:color})}/><GaugeSelect plug={selected.type === "plug"} value={selected.type === "plug" ? selected.size : selected.gauge} onChange={v => updatePiece(selected.type === "plug" ? {size:v} : {gauge:v})}/><RangeField label={selected.type === "plug" ? "Plug diameter" : selected.type === "hoop" ? "Inner diameter" : "End diameter"} value={selected.size} min={selected.type === "plug" ? 1.6 : selected.type === "hoop" ? 3 : 1} max={selected.type === "plug" ? 24 : selected.type === "hoop" ? 25 : 10} onChange={v => updatePiece({ size: v })}/>{selected.type !== "hoop" && <RangeField label={selected.type === "plug" ? "Wearable length" : selected.type === "barbell" ? "Bar length" : "Post length"} value={selected.length} min={2} max={25} onChange={v => updatePiece({ length: v })}/>}{selected.type !== "plug" && <RangeField label="Wire thickness" value={selected.gauge} min={0.6} max={5} step={0.1} onChange={v => updatePiece({ gauge: v })}/>}<div className="editor-divider"/><div className="pose-controls">
            <div className="pose-heading"><span className="micro-label">POSITION</span><button className="text-icon" onClick={() => updatePiece({adjustment:undefined})} aria-label="Reset position and rotation" title="Reset position and rotation"><RotateCcw size={13}/>Reset</button></div>
            {(["X", "Y", "Z"] as const).map((axis,index) => <RangeField key={axis} label={`Position ${axis}`} value={selected.adjustment?.position[index] || 0} min={-100} max={100} step={.1} onChange={v => { const position: V3 = [...(selected.adjustment?.position || [0,0,0])]; position[index]=v; updatePiece({adjustment:{position,rotation:selected.adjustment?.rotation || [0,0,0]}}); }}/>) }
            <span className="micro-label pose-rotation-heading">ROTATION</span>
            {(["X", "Y", "Z"] as const).map((axis,index) => <RangeField key={axis} label={`Rotation ${axis}`} value={selected.adjustment?.rotation[index] || 0} min={-180} max={180} step={1} unit="°" onChange={v => { const rotation: V3 = [...(selected.adjustment?.rotation || [0,0,0])]; rotation[index]=v; updatePiece({adjustment:{position:selected.adjustment?.position || [0,0,0],rotation}}); }}/>) }
          </div><LocationSelect lobeOnly={selected.type === "plug"} value={pieceLocation(selected) || locationId} onChange={relocateSelected} customPieces={pieces.filter(p=>p.custom)} allowAddCustom={false} label="MOVE TO PIERCING" occupied={pieces.filter(piece => piece.id !== selected.id).map(piece => piece.locationId).filter((id): id is PiercingId => !!id)}/><p className="locked-anchor-note"><MapPin size={11}/>Starting location: {selected.custom ? `Custom Piercing #${selected.customNumber}` : getLocation(selected.locationId)?.name || "preset"}.</p></div> : selectedChain ? <div className="piece-editor chain-editor"><div className="editor-heading"><span className="micro-label">SELECTED CHAIN</span><button className="delete-piece-button" aria-label="Delete selected chain" onClick={() => deleteChain(selectedChain.id)}><Trash2 size={14}/><span>Delete</span></button></div><h3>{chainName(selectedChain)}</h3><FinishPicker label="Chain finish" finish={selectedChain.finish} metalColor={selectedChain.metalColor} onChange={(value,color)=>updateChain({finish:value,metalColor:color})}/><RangeField label="Chain drop" value={selectedChain.drop} min={0} max={35} step={.5} onChange={v => updateChain({drop:v})}/><RangeField label="Chain wire thickness" value={selectedChain.thickness} min={.15} max={.8} step={.05} onChange={v => updateChain({thickness:v})}/></div> : <div className="editor-placeholder"><SlidersHorizontal size={20}/><p>No piece selected</p><span>Select jewelry to change its position, rotation, size, or finish.</span></div>}
        </aside>
      </div>

      <footer className="workspace-footer"><span className="save-status"><span className={`status-dot ${!localSaved ? "unsaved" : ""}`}/>{localSaved ? "Saved on this device" : "Storage full — export your plan"}</span><div><button aria-label="Ear appearance" onClick={() => setModal("appearance")}><span className={`material-dot ${clay ? "clay" : "texture"}`} style={clay ? {background:plan.skinTone || DEFAULT_SKIN_TONE} : undefined}/>{clay ? "Skin tone" : "Original texture"}<ChevronDown size={11}/></button><span className="footer-divider"/><button onClick={exportPlan}>Export plan<ArrowUpRight size={12}/></button></div></footer>
      <div className="rose-frieze" aria-hidden="true">
        <svg className="rose-art" viewBox="0 295 2172 245" preserveAspectRatio="xMidYMid meet"><image href={`${import.meta.env.BASE_URL}rose-petal-lace.png`} width="2172" height="724"/></svg>
      </div>
    </main>

    <input ref={modelInput} type="file" accept=".glb" className="sr-only" tabIndex={-1} onChange={e => importModel(e.target.files?.[0])}/><input ref={planInput} type="file" accept=".json" className="sr-only" tabIndex={-1} onChange={e => importPlan(e.target.files?.[0])}/>
    {notice && <div className="toast" role="status"><Check size={16}/><span>{notice}</span><button aria-label="Dismiss notification" onClick={() => setNotice("")}><X size={14}/></button></div>}

    {modal === "appearance" && <Modal title="Ear appearance" onClose={() => setModal(null)}>
      <div className="appearance-modes" role="group" aria-label="Ear material"><button aria-pressed={clay} className={clay ? "active" : ""} onClick={() => setClay(true)}>Skin tone</button><button aria-pressed={!clay} className={!clay ? "active" : ""} disabled={!engine?.supportsTextures} onClick={() => setClay(false)}>Original texture</button></div>
      <fieldset className="skin-tone-fieldset"><legend>SKIN TONE</legend><div className="skin-tones">{SKIN_TONES.map(tone => <button key={tone.color} className={`skin-tone ${clay && (plan.skinTone || DEFAULT_SKIN_TONE).toLowerCase() === tone.color ? "selected" : ""}`} aria-label={`${tone.name} skin tone`} aria-pressed={clay && (plan.skinTone || DEFAULT_SKIN_TONE).toLowerCase() === tone.color} onClick={() => applySkinTone(tone.color)}><span style={{background:tone.color}}/><small>{tone.name}</small></button>)}</div></fieldset>
      <label className="custom-skin-tone"><span>Custom color</span><input type="color" aria-label="Custom skin tone" value={plan.skinTone || DEFAULT_SKIN_TONE} onInput={e => applySkinTone(e.currentTarget.value)} onChange={e => applySkinTone(e.target.value)}/></label>
      <button className="btn btn-dark full-width" onClick={() => setModal(null)}>Done</button>
    </Modal>}
    {modal === "save" && <Modal title="Save arrangement" onClose={() => setModal(null)}><p className="modal-copy">Save the current arrangement for both ears.</p><form onSubmit={e => { e.preventDefault(); saveLook(); }}><label className="input-label" htmlFor="look-name">LOOK NAME</label><input data-autofocus id="look-name" className="text-input" value={lookName} maxLength={60} onChange={e => setLookName(e.target.value)}/><div className="save-preview">{engine && <img src={engine.snapshot(true)} alt="Preview of the current ear arrangement"/>}<div><strong>{plan.left.length + plan.right.length} pieces</strong><p>{plan.left.length} left · {plan.right.length} right</p><span>Saved in this browser on this device.</span></div></div><button type="submit" className="btn btn-dark full-width" disabled={!lookName.trim()}><Plus size={16}/>Save this look</button></form></Modal>}
    {modal === "saved" && <Modal title="Saved arrangements" wide onClose={() => setModal(null)}><p className="modal-copy">Arrangements saved in this browser.</p>{looks.length ? <div className="saved-grid">{looks.map(look => <article className="saved-card" key={look.id}><button className="saved-open" onClick={() => openLook(look)}><img src={look.thumbnail} alt={`Preview of ${look.name}`}/><span><strong>{look.name}</strong><small>{look.plan.left.length + look.plan.right.length} pieces · {new Date(look.savedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</small></span><ArrowUpRight size={17}/></button><button className="saved-delete" aria-label={`Delete saved look ${look.name}`} onClick={() => deleteLook(look.id)}><Trash2 size={14}/></button></article>)}</div> : <div className="empty-saved"><FolderOpen size={34}/><h3>No saved arrangements</h3><p>Arrange a few pieces, then use “Save look” to keep the combination.</p><button className="btn btn-dark" onClick={() => setModal(null)}>Back to planner<ArrowUpRight size={14}/></button></div>}<button className="btn btn-quiet full-width import-plan" onClick={() => planInput.current?.click()}><Upload size={15}/>Open an exported plan</button></Modal>}
    {modal === "model" && <Modal title="Ear model" onClose={() => { if (!importing) setModal(null); }}><p className="modal-copy">Use the test ear or import a self-contained GLB model.</p><div className="current-model"><span className="current-model-icon"><RoseMark/></span><div><span className="micro-label">CURRENT MODEL</span><strong>{plan.modelName}</strong><span>{plan.modelId === "demo-ear-v1" ? "Demo anatomy · mirrored for the opposite ear" : "Imported model · mirrored for the opposite ear"}</span></div></div><label className="input-label" htmlFor="model-height">REFERENCE EAR HEIGHT</label><div className="height-input"><input data-autofocus id="model-height" aria-label="Reference ear height" type="number" min="20" max="150" step="0.5" value={modelHeight} onChange={e => { const n = e.target.valueAsNumber; if (Number.isFinite(n)) setModelHeight(Math.min(150, Math.max(20, n))); }}/><span>mm</span><button onClick={calibrateHeight}>Apply height</button></div><p className="field-note">Use the top-to-bottom height of the cropped ear mesh. Jewelry keeps its actual dimensions when you change the reference height.</p><button className="model-upload" disabled={importing} onClick={() => modelInput.current?.click()}>{importing ? <Loader2 className="spin" size={24}/> : <Upload size={24}/>}<strong>{importing ? "Preparing your model…" : "Choose a 3D ear model"}</strong><span>Embedded .glb · Y-up · front facing +Z · up to 50 MB</span><small>The model is kept in this browser. Importing starts a new arrangement.</small></button>{plan.modelId !== "demo-ear-v1" && <button className="btn btn-quiet full-width" disabled={importing} onClick={() => { seed.current = false; commit(p => ({ ...EMPTY_PLAN, skinTone:p.skinTone })); setSelectedId(null); setModal(null); }}>Return to the test ear</button>}<p className="field-note">Photo-to-model reconstruction will be a separate step. This version accepts an already-created mesh.</p><p className="model-credit">Test model: “Human Ear” by <a href="https://sketchfab.com/girts.urbacans" target="_blank" rel="noreferrer">girts.urbacans</a>, <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0</a>, via <a href="https://aizity.com/assets/free-3d-model-download/human-ear-3d-model" target="_blank" rel="noreferrer">AiZity</a>. Centered, scaled to a nominal reference height, mirrored, and displayed with an optional clay material.</p></Modal>}

  </div>;
}
