# Elisa Branch

A personal 3D ear-piercing planner, with twelve named piercing presets and adjustable jewelry.

## Website

Published with GitHub Pages from the `main` branch, `/docs` folder.

## Features

- A rotatable 3D test ear, mirrored for left/right arrangements.
- Twelve fixed piercing locations: three lobe positions, three helix positions, flat, forward helix, rook, daith, conch, and tragus.
- Ball studs, gem studs, hoops, and barbells with dimensions, finish, rotation, and tilt controls.
- One piece per location; changing jewelry at an occupied location updates the piece.
- Saved looks in this browser, JSON plan import/export, and PNG image export.
- Self-contained GLB import with a reference-height control. Models must be cropped to the ear, Y-up, front facing +Z.
- WebGL rendering with a CPU canvas fallback. Photo textures require WebGL.

## Develop and publish

Requires Node.js 22.13 or newer.

```sh
npm ci
npm run dev
```

After making changes, run `npm run build` and commit the updated `docs/` folder along with the source. GitHub Pages publishes the committed output. Relative asset paths support project hosting and a future custom domain.

All arrangements and imported models stay in the visitor's browser. No backend or ChatGPT sign-in is required. Browser storage can be cleared; retain exported plans and original model files as backups. Data saved at a different website origin does not automatically transfer here.

## Limits

Preset locations are approximate landmarks for visual planning. They do not assess anatomical feasibility, tissue thickness, healing, or certified jewelry fit. The test ear is a surface model and the opposite ear is mirrored geometry. Photo reconstruction is not included.

## Model credit

“Human Ear” by girts.urbacans, CC BY 4.0, via AiZity. See `public/models/ATTRIBUTION.md`. The application centers, scales, mirrors, and optionally recolors the mesh.
