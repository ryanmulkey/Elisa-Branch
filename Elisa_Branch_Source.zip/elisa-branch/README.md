# Elisa Branch

A personal 3D ear-piercing planner, with sixteen named piercing presets and adjustable jewelry.

## Website

Published at https://ryanmulkey.github.io/Elisa-Branch/ from the `main` branch, repository root.

Desktop decoration appears above 1100 px with a fine pointer and hover support. Cathedral tracery, frame corners, and border details are decorative and do not intercept input. Phones and touch-only tablets retain the plain layout.

## Features

- A rotatable 3D test ear, mirrored for left/right arrangements.
- Sixteen fixed locations: four lobe positions; upper, mid, lower and floating helix; flat; two forward helix positions; rook; daith; snug; conch; tragus.
- Ball studs, gem studs, hoops, and barbells with dimensions, finish, rotation, tilt, and depth controls.
- One piece per location; changing jewelry at an occupied location updates the piece.
- Saved looks in this browser, JSON plan import/export, and PNG image export.
- Self-contained GLB import with a reference-height control. Models must be cropped to the ear, Y-up, front facing +Z.
- WebGL rendering with a CPU canvas fallback. Photo textures require WebGL.

## Develop and publish

Requires Node.js 22.13 or newer.

```sh
npm ci
npm run dev
```

After making changes, run `npm run build`. The output is in `docs/`. To update the current flat GitHub deployment, copy the generated JS and CSS to `app.js` and `styles.css` at repository root, update their paths in `index.html`, and copy `docs/models/test-ear.glb` to `test-ear.glb`. Replace `./models/test-ear.glb` with `./test-ear.glb` in the compiled JS. Commit these files along with the updated source archive. Relative asset paths support project hosting and a future custom domain.

All arrangements and imported models stay in the visitor's browser. No backend or ChatGPT sign-in is required. Browser storage can be cleared; retain exported plans and original model files as backups. Data saved at a different website origin does not automatically transfer here.

Depth is measured in millimeters along the surface normal: negative moves into the ear, positive moves away, and zero is on the surface. The slider supports −5 to +15 mm. Depth is included in saved looks and exported plans. New jewelry and the example arrangement default to silver; existing saved finishes are preserved.

## Limits

Preset locations are approximate landmarks for visual planning. They do not assess anatomical feasibility, tissue thickness, healing, or certified jewelry fit. The test ear is a surface model and the opposite ear is mirrored geometry. Photo reconstruction is not included.

## Model credit

“Human Ear” by girts.urbacans, CC BY 4.0, via AiZity. See `public/models/ATTRIBUTION.md`. The application centers, scales, mirrors, and optionally recolors the mesh.
