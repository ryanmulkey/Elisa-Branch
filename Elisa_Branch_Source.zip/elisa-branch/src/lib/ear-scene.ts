import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { EarSide, Finish, Piece, Plan, V3, Chain, canChain, makePiece, DEFAULT_SKIN_TONE } from "./planner";
import { PIERCING_LOCATIONS, getLocation, type PiercingId } from "./piercing-locations";
import { SoftwareRenderer } from "./software-renderer";

type Surface = { position: V3; normal: V3 };
type Callbacks = { onSelect: (id: string | null) => void };

export class EarScene {
  renderer: THREE.WebGLRenderer | SoftwareRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(34, 1, 0.1, 1000);
  controls: OrbitControls;
  modelRoot = new THREE.Group();
  jewelryRoot = new THREE.Group();
  hintRoot = new THREE.Group();
  earMeshes: THREE.Mesh[] = [];
  model: THREE.Object3D | null = null;
  rawHeight = 1;
  height = 65;
  side: EarSide = "left";
  clay = true;
  frame = 0;
  disposed = false;
  loadSequence = 0;
  observer: ResizeObserver;
  raycaster = new THREE.Raycaster();
  pointerStart = { x: 0, y: 0, multi: false };
  activePointers = new Set<number>();
  selection: THREE.Object3D | null = null;
  textureMaterials = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>();
  clayMaterial = new THREE.MeshStandardMaterial({ color: DEFAULT_SKIN_TONE, roughness: 0.73, metalness: 0, side: THREE.DoubleSide });
  environment: THREE.Texture | null = null;

  constructor(public container: HTMLDivElement, public callbacks: Callbacks) {
    try { this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, preserveDrawingBuffer: true }); }
    catch { this.renderer = new SoftwareRenderer(); }
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    if (this.renderer instanceof THREE.WebGLRenderer) {
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.15;
    }
    this.renderer.domElement.setAttribute("aria-label", "Interactive 3D ear. Drag to rotate, scroll or pinch to zoom. Jewelry is anchored to named piercing presets.");
    this.renderer.domElement.setAttribute("role", "img");
    container.appendChild(this.renderer.domElement);
    this.camera.position.set(0, 0, 145);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.enablePan = false;
    this.controls.minDistance = 65;
    this.controls.maxDistance = 270;
    this.controls.target.set(0, 0, 0);
    if (this.renderer instanceof THREE.WebGLRenderer) {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      const room = new RoomEnvironment();
      this.environment = pmrem.fromScene(room, 0.04).texture;
      this.scene.environment = this.environment;
      room.dispose(); pmrem.dispose();
    }
    this.scene.add(new THREE.HemisphereLight(0xfff9ee, 0xa69489, 2.1));
    const key = new THREE.DirectionalLight(0xfff9ee, 3.8); key.position.set(-45, 65, 90); this.scene.add(key);
    const fill = new THREE.DirectionalLight(0xffffff, 1.1); fill.position.set(50, 10, 60); this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xe7eeff, 2.6); rim.position.set(20, 30, -45); this.scene.add(rim);
    this.scene.add(this.modelRoot, this.jewelryRoot, this.hintRoot);
    this.renderer.domElement.style.cursor = "grab";
    this.observer = new ResizeObserver(() => this.resize()); this.observer.observe(container); this.resize();
    this.renderer.domElement.addEventListener("pointerdown", this.onDown);
    this.renderer.domElement.addEventListener("pointerup", this.onUp);
    this.renderer.domElement.addEventListener("pointercancel", this.onCancel);
    this.animate();
  }
  resize() {
    const { width, height } = this.container.getBoundingClientRect();
    if (!width || !height) return;
    this.camera.aspect = width / height; this.camera.updateProjectionMatrix(); this.renderer.setSize(width, height);
  }
  animate = () => { if (this.disposed) return; this.frame = requestAnimationFrame(this.animate); this.controls.update(); this.renderer.render(this.scene, this.camera); };
  async load(data?: ArrayBuffer) {
    const sequence = ++this.loadSequence;
    const loader = new GLTFLoader();
    if (data) loader.manager.setURLModifier(url => { if (url.startsWith("blob:") || url.startsWith("data:")) return url; throw new Error("Please export a self-contained GLB with embedded textures."); });
    const gltf = data ? await loader.parseAsync(data, "") : await loader.loadAsync(`${import.meta.env.BASE_URL}models/test-ear.glb`);
    if (sequence !== this.loadSequence || this.disposed) { this.disposeObject(gltf.scene); return false; }
    const box = new THREE.Box3().setFromObject(gltf.scene);
    const size = box.getSize(new THREE.Vector3());
    if (![size.x, size.y, size.z].every(Number.isFinite) || size.y <= 0.000001 || size.length() > 1e9) { this.disposeObject(gltf.scene); throw new Error("This model has no usable geometry. Export a Y-up ear mesh as GLB."); }
    if (this.model) this.disposeObject(this.model);
    this.modelRoot.clear(); this.earMeshes = []; this.textureMaterials.clear();
    this.rawHeight = size.y;
    const centered = new THREE.Group(); centered.add(gltf.scene);
    gltf.scene.position.sub(box.getCenter(new THREE.Vector3()));
    gltf.scene.traverse(object => {
      if (object instanceof THREE.Mesh) {
        if (!object.geometry.attributes.normal) object.geometry.computeVertexNormals();
        this.earMeshes.push(object); this.textureMaterials.set(object, object.material);
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        materials.forEach(material => { material.side = THREE.DoubleSide; });
        if (this.clay) object.material = this.clayMaterial;
      }
    });
    if (!this.earMeshes.length) throw new Error("No mesh was found in this GLB.");
    this.model = centered; this.modelRoot.add(centered); this.setHeight(this.height); this.setSide(this.side); this.resetView();
    this.modelRoot.updateMatrixWorld(true); return true;
  }
  invalidate() { if (this.renderer instanceof SoftwareRenderer) this.renderer.dirty = true; }
  setHeight(height: number) { this.height = height; const s = height / this.rawHeight; this.modelRoot.scale.set(this.side === "left" ? s : -s, s, s); this.modelRoot.updateMatrixWorld(true); this.invalidate(); }
  setSide(side: EarSide) { this.side = side; this.setHeight(this.height); }
  setClay(clay: boolean) { this.clay = clay; this.earMeshes.forEach(mesh => { mesh.material = clay ? this.clayMaterial : this.textureMaterials.get(mesh)!; }); this.invalidate(); }
  setSkinTone(color: string) {
    if (!/^#[0-9a-f]{6}$/i.test(color)) return;
    this.clayMaterial.color.set(color); this.invalidate();
  }
  get supportsTextures() { return this.renderer instanceof THREE.WebGLRenderer; }
  resetView(view: "front" | "angle" | "back" = "front") {
    const distance = Math.max(125, this.height * 2.22);
    if (view === "angle") this.camera.position.set((this.side === "left" ? -1 : 1) * distance * 0.53, 6, distance * 0.85);
    else if (view === "back") this.camera.position.set(0, 0, -distance);
    else this.camera.position.set(0, 0, distance);
    this.controls.target.set(0, 0, 0); this.controls.update();
  }
  zoom(direction: 1 | -1) { this.camera.position.multiplyScalar(direction === 1 ? 0.86 : 1.16); this.camera.position.clampLength(this.controls.minDistance, this.controls.maxDistance); this.controls.update(); }
  private getSurface(hit: THREE.Intersection): Surface {
    const normal = hit.normal?.clone() || hit.face!.normal.clone();
    normal.applyMatrix3(new THREE.Matrix3().getNormalMatrix(hit.object.matrixWorld)).normalize();
    if (normal.dot(this.raycaster.ray.direction) > 0) normal.negate();
    return { position: hit.point.toArray() as V3, normal: normal.toArray() as V3 };
  }
  surfaceAt(x: number, y: number): Surface | null {
    this.modelRoot.updateMatrixWorld(true);
    this.raycaster.set(new THREE.Vector3(x, y, 200), new THREE.Vector3(0, 0, -1));
    const hit = this.raycaster.intersectObjects(this.earMeshes, false)[0]; return hit ? this.getSurface(hit) : null;
  }
  presetSurface(id: PiercingId, side: EarSide = this.side): Surface | null {
    const spec = getLocation(id); if (!spec) return null;
    const previous = this.side; this.setSide(side);
    const sign = side === "left" ? 1 : -1;
    const result = this.surfaceAt(sign * spec.x * this.height / 65, spec.y * this.height / 65);
    this.setSide(previous); return result;
  }
  presetPiece(id: PiercingId, side: EarSide, type?: Piece["type"], finish: Finish = "silver"): Piece | null {
    const spec = getLocation(id); if (!spec) return null;
    if ((type || spec.type) === "plug" && spec.group !== "Lobe") return null;
    const surface = this.presetSurface(id, side); if (!surface) return null;
    const p = makePiece(type || spec.type, surface.position, surface.normal, finish);
    p.locationId = id; p.name = spec.name;
    if (!type || type === spec.type) p.size = spec.size;
    p.rotation = spec.rotation * (side === "left" ? 1 : -1); p.tilt = spec.tilt;
    return p;
  }
  snapPlan(plan: Plan): Plan {
    this.setHeight(plan.height);
    const snap = (side: EarSide) => {
      const used = new Set<PiercingId>();
      return plan[side].map(p => {
        const sign = side === "left" ? 1 : -1;
        const named = getLocation(p.locationId) || PIERCING_LOCATIONS.find(location => location.name.toLowerCase() === p.name.toLowerCase() && !used.has(location.id));
        const candidates = [...PIERCING_LOCATIONS].sort((a, b) => Math.hypot(p.position[0] - sign * a.x * plan.height / 65, p.position[1] - a.y * plan.height / 65) - Math.hypot(p.position[0] - sign * b.x * plan.height / 65, p.position[1] - b.y * plan.height / 65));
        const spec = named || candidates.find(location => !used.has(location.id)) || candidates[0];
        used.add(spec.id);
        const surface = this.presetSurface(spec.id, side);
        // Old looks retain every piece; missing regions on custom scans are hidden.
        return { ...p, locationId: spec.id, ...(surface || {}), visible: !!surface && p.visible };
      });
    };
    return { ...plan, left: snap("left"), right: snap("right") };
  }
  starter(side: EarSide): Piece[] { return (["lobe-1", "lobe-2", "helix-upper"] as const).map(id => this.presetPiece(id, side)).filter((piece): piece is Piece => !!piece); }
  setPresetHint(id: PiercingId | null) {
    this.hintRoot.children.forEach(child => this.disposeObject(child)); this.hintRoot.clear();
    if (!id) { this.invalidate(); return; }
    const surface = this.presetSurface(id); if (!surface) { this.invalidate(); return; }
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.13, 6, 40), new THREE.MeshBasicMaterial({ color: "#ca4540", depthTest: false }));
    ring.position.fromArray(surface.position); ring.position.addScaledVector(new THREE.Vector3(...surface.normal), 0.6);
    ring.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(...surface.normal)); ring.renderOrder = 6;
    this.hintRoot.add(ring); this.invalidate();
  }
  setPieces(pieces: Piece[], selectedId: string | null, chains: Chain[] = []) {
    this.jewelryRoot.children.forEach(child => this.disposeObject(child)); this.jewelryRoot.clear(); this.selection = null;
    for (const p of pieces) {
      if (!p.visible) continue;
      const group = this.makeJewelry(p); group.position.fromArray(p.position);
      const normal = new THREE.Vector3(...p.normal).normalize(); group.position.addScaledVector(normal, p.lift);
      group.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
      group.rotateZ(THREE.MathUtils.degToRad(p.rotation)); group.rotateY(THREE.MathUtils.degToRad(p.tilt));
      group.traverse(o => { o.userData.pieceId = p.id; });
      if (p.id === selectedId) {
        const r = p.type === "hoop" ? p.size / 2 + p.gauge + 1.1 : Math.max(p.size / 2 + 1.3, 2.6);
        const halo = new THREE.Mesh(new THREE.TorusGeometry(r, 0.11, 6, 64), new THREE.MeshBasicMaterial({ color: "#ca4540", transparent: true, opacity: 0.85, depthTest: false }));
        halo.position.set(0, p.type === "hoop" ? -(p.size + p.gauge) / 2 : 0, 1); halo.renderOrder = 5; halo.userData.selection = true; group.add(halo); this.selection = halo;
      }
      this.jewelryRoot.add(group);
    }
    for (const c of chains) {
      const a = pieces.find(p => p.id === c.fromId), b = pieces.find(p => p.id === c.toId);
      if (!c.visible || !a?.visible || !b?.visible || !canChain(a) || !canChain(b)) continue;
      const chain = this.makeChain(c, a, b);
      chain.traverse(o => { o.userData.pieceId = c.id; });
      this.jewelryRoot.add(chain);
    }
    this.invalidate();
  }
  private chainAnchor(p: Piece) {
    const normal = new THREE.Vector3(...p.normal).normalize();
    const rotation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,1), normal);
    rotation.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1), THREE.MathUtils.degToRad(p.rotation)));
    rotation.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0), THREE.MathUtils.degToRad(p.tilt)));
    const local = p.type === "hoop" ? new THREE.Vector3(0, -(p.size + p.gauge), 0) : new THREE.Vector3(0, 0, p.size * .55 + .5);
    return local.applyQuaternion(rotation).add(new THREE.Vector3(...p.position).addScaledVector(normal, p.lift));
  }
  private makeChain(c: Chain, a: Piece, b: Piece) {
    const start = this.chainAnchor(a), end = this.chainAnchor(b);
    const control = start.clone().add(end).multiplyScalar(.5); control.y -= c.drop * 2;
    const curve = new THREE.QuadraticBezierCurve3(start, control, end);
    const points = curve.getPoints(48).map((point, index) => {
      if (index === 0 || index === 48) return point;
      // Keep the visual drape in front of the mesh where it crosses the ear.
      const surface = this.surfaceAt(point.x, point.y);
      if (surface) point.z = Math.max(point.z, surface.position[2] + c.thickness * 3 + .6);
      return point;
    });
    const path = new THREE.CatmullRomCurve3(points);
    const group = new THREE.Group();
    const colors = { silver: "#e2e5e8", gold: "#d9b568", rose: "#d9a294" };
    const material = new THREE.MeshStandardMaterial({color:colors[c.finish],metalness:.94,roughness:.2});
    const count = Math.max(3, Math.min(160, Math.ceil(path.getLength() / (c.thickness * 3.5))));
    for (let i = 0; i <= count; i++) {
      const t = i/count;
      const link = new THREE.Mesh(new THREE.TorusGeometry(c.thickness * 1.8, c.thickness / 2, 5, 12), material);
      link.scale.y = 1.35; link.position.copy(path.getPointAt(t));
      link.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),path.getTangentAt(t).normalize());
      link.rotateY(i % 2 ? Math.PI / 2 : 0); group.add(link);
    }
    return group;
  }
  private makeJewelry(p: Piece) {
    const group = new THREE.Group();
    const color: Record<Finish, string> = { gold: "#d9b568", silver: "#e2e5e8", rose: "#d9a294" };
    const metal = new THREE.MeshStandardMaterial({ color: color[p.finish], metalness: 0.94, roughness: 0.18 });
    const sphere = (radius: number, position: V3, material: THREE.Material = metal) => { const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 24, 16), material); mesh.position.fromArray(position); group.add(mesh); return mesh; };
    const cylinder = (radius: number, length: number, position: V3, alongZ = true) => { const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, length, 20), metal); if (alongZ) mesh.rotation.x = Math.PI / 2; mesh.position.fromArray(position); group.add(mesh); return mesh; };
    if (p.type === "plug") {
      const plugBody = cylinder(p.size / 2, p.length, [0,0,-p.length / 2]);
      plugBody.material = new THREE.MeshStandardMaterial({color:"#151515",roughness:.3,metalness:.25});
      const face = new THREE.Mesh(new THREE.CircleGeometry(p.size * .45, 32), new THREE.MeshStandardMaterial({color:"#151515",roughness:.3,metalness:.25}));
      face.position.z = .77; group.add(face);
      const rim = new THREE.Mesh(new THREE.TorusGeometry(p.size * .51, p.size * .065, 10, 36), metal);
      rim.position.z = .8; group.add(rim);
    } else if (p.type === "hoop") {
      // Size means inner diameter, not the centerline diameter of the torus.
      const radius = (p.size + p.gauge) / 2;
      const hoop = new THREE.Mesh(new THREE.TorusGeometry(radius, p.gauge / 2, 14, 80), metal); hoop.rotation.y = Math.PI / 2; hoop.position.set(0, -radius, 0); group.add(hoop);
    } else if (p.type === "barbell") {
      cylinder(p.gauge / 2, p.length, [0, -p.length / 2, 0], false); sphere(p.size / 2, [0, 0, 0]); sphere(p.size / 2, [0, -p.length, 0]);
    } else {
      cylinder(p.gauge / 2, p.length, [0, 0, -p.length / 2]); cylinder(p.size * 0.38, 0.7, [0, 0, -p.length]);
      if (p.type === "stud") sphere(p.size / 2, [0, 0, p.size * 0.22]);
      else {
        cylinder(p.size / 2, 0.8, [0, 0, 0.2]);
        const gem = new THREE.Mesh(new THREE.OctahedronGeometry(p.size * 0.46, 0), new THREE.MeshPhysicalMaterial({ color: "#fbfffb", metalness: 0.14, roughness: 0.06, clearcoat: 1, ior: 2.1, envMapIntensity: 1.6 }));
        gem.rotation.z = Math.PI / 4; gem.scale.z = 0.52; gem.position.z = 0.75; group.add(gem);
        for (let i = 0; i < 4; i++) sphere(p.size * 0.055, [Math.cos(i * Math.PI / 2) * p.size * 0.43, Math.sin(i * Math.PI / 2) * p.size * 0.43, 0.8]);
      }
    }
    return group;
  }
  onDown = (event: PointerEvent) => { this.activePointers.add(event.pointerId); if (this.activePointers.size > 1) this.pointerStart.multi = true; else this.pointerStart = { x: event.clientX, y: event.clientY, multi: false }; };
  onCancel = (event: PointerEvent) => { this.activePointers.delete(event.pointerId); this.pointerStart.multi = true; };
  onUp = (event: PointerEvent) => {
    this.activePointers.delete(event.pointerId);
    if (event.button !== 0 || this.pointerStart.multi || Math.hypot(event.clientX - this.pointerStart.x, event.clientY - this.pointerStart.y) > 6) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.raycaster.setFromCamera(new THREE.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1), this.camera);
    const ear = this.raycaster.intersectObjects(this.earMeshes, false)[0];
    const jewelry = this.raycaster.intersectObjects(this.jewelryRoot.children, true).find(hit => hit.object.userData.pieceId && !hit.object.userData.selection);
    if (jewelry && (!ear || jewelry.distance <= ear.distance + 2)) this.callbacks.onSelect(jewelry.object.userData.pieceId);
    else this.callbacks.onSelect(null);
  };
  snapshot(thumbnail = false): string {
    this.hintRoot.visible = false;
    if (this.selection) this.selection.visible = false; this.invalidate(); this.renderer.render(this.scene, this.camera);
    const canvas = document.createElement("canvas"); const source = this.renderer.domElement;
    const ratio = thumbnail ? Math.min(1, 320 / source.width) : 1;
    canvas.width = source.width * ratio; canvas.height = source.height * ratio;
    const ctx = canvas.getContext("2d")!; ctx.fillStyle = "#121212"; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    if (this.selection) this.selection.visible = true; this.hintRoot.visible = true; this.invalidate();
    return canvas.toDataURL(thumbnail ? "image/webp" : "image/png", 0.85);
  }
  private disposeObject(object: THREE.Object3D) {
    const materials = new Set<THREE.Material>();
    object.traverse(o => { if (o instanceof THREE.Mesh) { o.geometry.dispose(); const source = this.textureMaterials.get(o) || o.material; (Array.isArray(source) ? source : [source]).forEach(m => { if (m !== this.clayMaterial) materials.add(m); }); } });
    materials.forEach(material => { const m = material as THREE.MeshStandardMaterial; m.map?.dispose(); m.normalMap?.dispose(); m.roughnessMap?.dispose(); material.dispose(); });
  }
  dispose() { this.disposed = true; this.loadSequence++; cancelAnimationFrame(this.frame); this.observer.disconnect(); this.controls.dispose(); this.renderer.domElement.removeEventListener("pointerdown", this.onDown); this.renderer.domElement.removeEventListener("pointerup", this.onUp); this.renderer.domElement.removeEventListener("pointercancel", this.onCancel); if (this.model) this.disposeObject(this.model); this.jewelryRoot.children.forEach(o => this.disposeObject(o)); this.hintRoot.children.forEach(o => this.disposeObject(o)); this.clayMaterial.dispose(); this.environment?.dispose(); this.renderer.dispose(); this.renderer.domElement.remove(); }
}
