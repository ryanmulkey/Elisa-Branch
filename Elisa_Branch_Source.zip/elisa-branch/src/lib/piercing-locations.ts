import type { JewelryType } from "./planner";

export type PiercingId = "lobe-1" | "lobe-2" | "lobe-3" | "lobe-4" | "helix-upper" | "helix-mid" | "helix-lower" | "flat" | "forward-helix" | "forward-helix-2" | "floating-helix" | "snug" | "rook" | "daith" | "conch" | "tragus";
export interface PiercingLocation {
  id: PiercingId;
  name: string;
  group: "Lobe" | "Outer cartilage" | "Inner cartilage";
  description: string;
  // Front-view coordinates on the centered, 65 mm test ear, mirrored for the opposite ear.
  x: number;
  y: number;
  type: JewelryType;
  size: number;
  rotation: number;
  tilt: number;
}

export const PIERCING_LOCATIONS: PiercingLocation[] = [
  { id: "lobe-1", name: "First lobe", group: "Lobe", description: "The lower, soft part of the earlobe.", x: 2, y: -26, type: "stud", size: 3.5, rotation: 0, tilt: 0 },
  { id: "lobe-2", name: "Second lobe", group: "Lobe", description: "A second position just above the first lobe.", x: -1, y: -20, type: "gem", size: 2.8, rotation: 0, tilt: 0 },
  { id: "lobe-3", name: "Third lobe", group: "Lobe", description: "The upper part of the lobe, approaching the outer rim.", x: -7, y: -15, type: "stud", size: 2.5, rotation: 0, tilt: 0 },
  { id: "lobe-4", name: "Fourth / upper lobe", group: "Lobe", description: "Above the third lobe, near the lobe–cartilage boundary.", x: -12, y: -11, type: "stud", size: 2.5, rotation: 0, tilt: 0 },
  { id: "helix-upper", name: "Upper helix", group: "Outer cartilage", description: "The upper section of the outer cartilage rim.", x: -17, y: 18, type: "hoop", size: 6, rotation: -20, tilt: 24 },
  { id: "helix-mid", name: "Mid helix", group: "Outer cartilage", description: "The middle section of the outer cartilage rim.", x: -21, y: 5, type: "hoop", size: 8, rotation: -65, tilt: 24 },
  { id: "helix-lower", name: "Lower helix", group: "Outer cartilage", description: "The lower outer rim, above the lobe.", x: -17, y: -8, type: "hoop", size: 7, rotation: -100, tilt: 24 },
  { id: "flat", name: "Flat", group: "Outer cartilage", description: "The flat cartilage area inside the upper rim.", x: -7, y: 18, type: "gem", size: 3.5, rotation: 0, tilt: 0 },
  { id: "forward-helix", name: "Forward helix", group: "Outer cartilage", description: "The front of the upper rim, where the ear meets the head.", x: 10, y: 16, type: "gem", size: 2.5, rotation: 0, tilt: 0 },
  { id: "forward-helix-2", name: "Second forward helix", group: "Outer cartilage", description: "A second position above the forward helix, toward the top rim.", x: 8, y: 21, type: "gem", size: 2.5, rotation: 0, tilt: 0 },
  { id: "floating-helix", name: "Floating helix", group: "Outer cartilage", description: "A vertical position through the top rim, with jewelry below it.", x: -8, y: 28, type: "barbell", size: 2.5, rotation: 0, tilt: 0 },
  { id: "rook", name: "Rook", group: "Inner cartilage", description: "The inner cartilage ridge above the daith and tragus.", x: 3, y: 10, type: "hoop", size: 5, rotation: 0, tilt: 60 },
  { id: "daith", name: "Daith", group: "Inner cartilage", description: "The small inner fold just above the ear canal.", x: 8, y: -2, type: "hoop", size: 8, rotation: 10, tilt: 65 },
  { id: "snug", name: "Snug", group: "Inner cartilage", description: "Across the antihelix ridge, above the lower outer rim.", x: -10, y: -3, type: "barbell", size: 2.5, rotation: 80, tilt: 0 },
  { id: "conch", name: "Conch", group: "Inner cartilage", description: "The cup-shaped bowl in the center of the ear.", x: 1, y: -5, type: "gem", size: 4, rotation: 0, tilt: 0 },
  { id: "tragus", name: "Tragus", group: "Inner cartilage", description: "The small cartilage projection in front of the ear canal.", x: 12, y: -9, type: "stud", size: 2.5, rotation: 0, tilt: 0 },
];
export const LOCATION_GROUPS = ["Lobe", "Outer cartilage", "Inner cartilage"] as const;
export function getLocation(id?: string): PiercingLocation | undefined { return PIERCING_LOCATIONS.find(location => location.id === id); }
