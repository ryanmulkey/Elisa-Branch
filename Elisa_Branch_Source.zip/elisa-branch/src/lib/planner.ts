import { getLocation, type PiercingId } from "./piercing-locations";

export type EarSide = "left" | "right";
export type JewelryType = "stud" | "hoop" | "gem" | "barbell";
export type Finish = "gold" | "silver" | "rose";
export type V3 = [number, number, number];

export interface Piece {
  id: string;
  name: string;
  locationId?: PiercingId;
  type: JewelryType;
  position: V3;
  normal: V3;
  size: number;
  length: number;
  gauge: number;
  rotation: number;
  tilt: number;
  lift: number;
  finish: Finish;
  visible: boolean;
}
export interface Plan {
  version: 1;
  modelId: string;
  modelName: string;
  height: number;
  left: Piece[];
  right: Piece[];
}
export interface SavedLook {
  id: string;
  name: string;
  savedAt: string;
  side: EarSide;
  plan: Plan;
  thumbnail: string;
}
export const TYPES: {id: JewelryType; name: string; note: string; size: number}[] = [
  { id: "stud", name: "Ball stud", note: "Round end", size: 3 },
  { id: "hoop", name: "Hoop", note: "Circular ring", size: 8 },
  { id: "gem", name: "Gem stud", note: "Faceted stone", size: 3.5 },
  { id: "barbell", name: "Barbell", note: "Two ball ends", size: 3 },
];
export const FINISHES = [
  { id: "gold" as Finish, name: "Gold", color: "#d3b36d" },
  { id: "silver" as Finish, name: "Silver", color: "#cbd0d2" },
  { id: "rose" as Finish, name: "Rose gold", color: "#d2a18d" },
];
export const EMPTY_PLAN: Plan = { version: 1, modelId: "demo-ear-v1", modelName: "Test ear", height: 65, left: [], right: [] };
export function makePiece(type: JewelryType, position: V3, normal: V3, finish: Finish = "silver"): Piece {
  return { id: crypto.randomUUID(), name: TYPES.find(t => t.id === type)!.name, type, position, normal, size: TYPES.find(t => t.id === type)!.size, length: 8, gauge: 1.2, rotation: 0, tilt: type === "hoop" ? 24 : 0, lift: 0.7, finish, visible: true };
}
function finite(value: unknown, min: number, max: number): value is number {
  return typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
}
function vector(value: unknown): value is V3 {
  return Array.isArray(value) && value.length === 3 && value.every(v => finite(v, -10000, 10000));
}
export function isPlan(value: unknown): value is Plan {
  if (!value || typeof value !== "object") return false;
  const p = value as Plan;
  return p.version === 1 && typeof p.modelId === "string" && typeof p.modelName === "string" && p.modelName.length < 300 && finite(p.height, 20, 150) && [p.left, p.right].every(items => Array.isArray(items) && items.length <= 100 && items.every((item: Piece) => item && typeof item.id === "string" && typeof item.name === "string" && item.name.length < 120 && (item.locationId === undefined || !!getLocation(item.locationId)) && TYPES.some(t => t.id === item.type) && FINISHES.some(f => f.id === item.finish) && vector(item.position) && vector(item.normal) && Math.hypot(...item.normal) > 0.01 && finite(item.size, 0.5, 40) && finite(item.length, 1, 60) && finite(item.gauge, 0.5, 5) && finite(item.rotation, -180, 180) && finite(item.tilt, -90, 90) && finite(item.lift, -5, 15) && typeof item.visible === "boolean"));
}
function modelStore(mode: IDBTransactionMode): Promise<IDBObjectStore> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("ear-studio-models", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("models");
    request.onerror = () => reject(new Error("Model storage is unavailable in this browser."));
    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction("models", mode);
      tx.oncomplete = () => db.close();
      resolve(tx.objectStore("models"));
    };
  });
}
export async function storeModel(id: string, data: ArrayBuffer) {
  const store = await modelStore("readwrite");
  return new Promise<void>((resolve, reject) => {
    store.put(data, id);
    store.transaction.oncomplete = () => { store.transaction.db.close(); resolve(); };
    store.transaction.onerror = () => reject(new Error("The model could not be saved on this device."));
    store.transaction.onabort = () => reject(new Error("The model could not be saved on this device."));
  });
}
export async function readModel(id: string): Promise<ArrayBuffer> {
  const store = await modelStore("readonly");
  return new Promise((resolve, reject) => {
    const request = store.get(id);
    request.onsuccess = () => request.result ? resolve(request.result) : reject(new Error("This look’s model is missing. Import the original GLB again."));
    request.onerror = () => reject(new Error("The saved model could not be opened."));
  });
}
export function downloadFile(contents: Blob | string, filename: string, mime = "application/json") {
  const blob = contents instanceof Blob ? contents : new Blob([contents], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
