import * as THREE from "three";

// A small CPU renderer keeps the same real mesh, camera, and picking behavior on
// devices where WebGL is disabled. It deliberately avoids texture interpolation.
export class SoftwareRenderer {
  domElement = document.createElement("canvas");
  ctx: CanvasRenderingContext2D;
  pixelRatio = 1;
  width = 1;
  height = 1;
  dirty = true;
  lastCamera = "";
  constructor() {
    const context = this.domElement.getContext("2d", { alpha: true });
    if (!context) throw new Error("Canvas rendering is unavailable.");
    this.ctx = context;
  }
  setPixelRatio(ratio: number) { this.pixelRatio = Math.min(ratio, 1.5); }
  setSize(width: number, height: number) { this.width = width; this.height = height; this.domElement.width = Math.round(width * this.pixelRatio); this.domElement.height = Math.round(height * this.pixelRatio); this.domElement.style.width = `${width}px`; this.domElement.style.height = `${height}px`; this.dirty = true; }
  dispose() { this.domElement.width = 1; this.domElement.height = 1; }
  render(scene: THREE.Scene, camera: THREE.Camera) {
    camera.updateMatrixWorld();
    const signature = camera.matrixWorld.elements.join(",") + camera.projectionMatrix.elements.join(",");
    if (!this.dirty && signature === this.lastCamera) return;
    this.lastCamera = signature; this.dirty = false;
    scene.updateMatrixWorld(true);
    const matrix = new THREE.Matrix4(); const vp = new THREE.Matrix4().multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
    const normalMatrix = new THREE.Matrix3();
    const light = new THREE.Vector3(-0.45, 0.7, 1).normalize();
    const fill = new THREE.Vector3(0.8, 0.15, 0.6).normalize();
    const normal = new THREE.Vector3(), center = new THREE.Vector3(), eye = new THREE.Vector3(), half = new THREE.Vector3();
    const p = new THREE.Vector3(), n = new THREE.Vector3();
    type Face = { z: number; points: number[]; color: string; overlay: boolean };
    const faces: Face[] = [];
    scene.traverseVisible(object => {
      if (!(object instanceof THREE.Mesh)) return;
      const geometry = object.geometry; const pos = geometry.attributes.position; const normals = geometry.attributes.normal;
      if (!pos) return;
      const material = (Array.isArray(object.material) ? object.material[0] : object.material) as THREE.MeshStandardMaterial;
      if (!material.visible) return;
      matrix.multiplyMatrices(vp, object.matrixWorld); normalMatrix.getNormalMatrix(object.matrixWorld);
      const indices = geometry.index; const count = indices ? indices.count : pos.count;
      const projected = new Float64Array(pos.count * 3);
      for (let i = 0; i < pos.count; i++) {
        p.fromBufferAttribute(pos, i).applyMatrix4(matrix);
        projected[i * 3] = (p.x + 1) / 2 * this.width; projected[i * 3 + 1] = (1 - p.y) / 2 * this.height; projected[i * 3 + 2] = p.z;
      }
      const base = material.color || new THREE.Color("#b89b80");
      for (let i = 0; i < count; i += 3) {
        const a = indices ? indices.getX(i) : i, b = indices ? indices.getX(i + 1) : i + 1, c = indices ? indices.getX(i + 2) : i + 2;
        const za = projected[a * 3 + 2], zb = projected[b * 3 + 2], zc = projected[c * 3 + 2];
        if (Math.min(za, zb, zc) < -1 || Math.max(za, zb, zc) > 1) continue;
        const points = [projected[a * 3], projected[a * 3 + 1], projected[b * 3], projected[b * 3 + 1], projected[c * 3], projected[c * 3 + 1]];
        if (Math.max(points[0], points[2], points[4]) < 0 || Math.min(points[0], points[2], points[4]) > this.width || Math.max(points[1], points[3], points[5]) < 0 || Math.min(points[1], points[3], points[5]) > this.height) continue;
        normal.set(0, 0, 0); center.set(0, 0, 0);
        for (const index of [a, b, c]) { center.add(p.fromBufferAttribute(pos, index)); if (normals) normal.add(n.fromBufferAttribute(normals, index)); }
        center.multiplyScalar(1 / 3).applyMatrix4(object.matrixWorld);
        normal.applyMatrix3(normalMatrix).normalize(); eye.subVectors(camera.position, center).normalize();
        if (normal.dot(eye) < 0) normal.negate();
        const diffuse = Math.max(0, normal.dot(light)), side = Math.max(0, normal.dot(fill));
        half.addVectors(light, eye).normalize();
        const metal = material.metalness || 0;
        const specular = Math.pow(Math.max(0, normal.dot(half)), metal > 0.5 ? 28 : 50) * (metal > 0.5 ? 0.6 : 0.025);
        const illumination = material instanceof THREE.MeshBasicMaterial ? 1 : 0.36 + diffuse * 0.62 + side * 0.16;
        const channel = (x: number) => Math.round(Math.pow(Math.min(1, Math.max(0, x * illumination + specular)), 1 / 2.2) * 255);
        faces.push({ z: (za + zb + zc) / 3, points, color: `rgb(${channel(base.r)},${channel(base.g)},${channel(base.b)})`, overlay: material.depthTest === false });
      }
    });
    faces.sort((a, b) => Number(a.overlay) - Number(b.overlay) || b.z - a.z);
    const ctx = this.ctx; ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0); ctx.clearRect(0, 0, this.width, this.height);
    ctx.lineWidth = 0.45; ctx.lineJoin = "round";
    for (const face of faces) { const v = face.points; ctx.beginPath(); ctx.moveTo(v[0], v[1]); ctx.lineTo(v[2], v[3]); ctx.lineTo(v[4], v[5]); ctx.closePath(); ctx.fillStyle = face.color; ctx.strokeStyle = face.color; ctx.fill(); ctx.stroke(); }
  }
}
