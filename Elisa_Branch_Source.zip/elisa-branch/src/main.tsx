import { createRoot } from 'react-dom/client';
import EarPlanner from './components/ear-planner';
import './styles.css';

createRoot(document.getElementById('root')!).render(<EarPlanner />);
